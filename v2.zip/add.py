# -*- coding: UTF-8 -*-
import time
import datetime
import os
import re
import base64
import requests
import sys
import codecs
import random
import smtplib
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import subprocess
import json
sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

if os.path.dirname(__file__) != '':
    os.chdir(os.path.dirname(__file__))

now_time = datetime.datetime.now()
now_time = now_time.strftime("%Y-%m-%d %X")
fundnow = datetime.datetime.now()
fyear = fundnow.year
fmonth = fundnow.month
fday = fundnow.day
key = sys.argv[1].encode('utf-8', errors='surrogateescape').decode('utf-8')
key = key.split('_')
who = key[0]
who_status = key[1]
who_input = key[2]
who_ip = key[3]
try:
    version = key[4]
except:
     version = ""
status_dict={"0":"起床囉!",
             "1":"準備午餐中!",
             "2":"出門去!",
             "3":"工作中!",
             "4":"吃晚餐!",
             "5":"洗澡中!",
             "6":"愛睏中!",
             "7":"其他!"}

who_status_ck = ""
who_input_ck = ""
try:
   with open("lst.txt","r",encoding="utf_8_sig") as v:
        vc = eval(v.read())
        for i in vc:
            index = i
            #if vc[i]['who'] == who:
            #who_status_ck = vc[i]['who_status']
            #who_input_ck = vc[i]['who_input']
        index = int(index)+1
except:
    os.system('echo {} > lst.txt')
    vc = {}
    index = 1

#if who_status_ck == who_status and who_input_ck == who_input:
#    print("<script>console.log('阻擋重複訊息~');</script>")
#    print("<script>parent.document.querySelector('#%s_send_input').value=''</script>" % who)
#    sys.exit()

vc.setdefault( index ,"dafault")
vc[index]={"who_status":"%s" % who_status,"who_input":"%s" % who_input,"who_ip":"%s" % who_ip,"who_time":"%s" % now_time,"who":"%s" % who}
with open("lst.txt","w",encoding="utf_8_sig") as v:
    v.write(str(vc))
    #json.dump(vc, v, ensure_ascii=False)
clean_script='''<script>parent.document.querySelector('#%s_send_input').value='';</script>''' % who


if version != "2":
    if who=="kiki":
        js_script='''<script>parent.document.querySelector("#myframe2").src="https://author.lugeshop.com/sch/search.php"</script>'''
    else:
        js_script='''<script>parent.document.querySelector("#myframe2").src="https://author.lugeshop.com/sch/search_no_alert.php"</script>'''
else:
    js_script= '''<script>parent.renew();</script>'''
js2='''<script>parent.document.querySelector("#myframe").src='';</script>'''
print(clean_script)
print(js_script)
print(js2)
def makekey(nn):
    tc = string.ascii_lowercase
    if nn==0:
        mk = tc[random.randint(0,25)]
    else:
        mk = str(random.randint(0,9))
    return mk
if who_status != "7":
    who_input = status_dict[who_status]

#requests.get("https://maker.ifttt.com/trigger/Play_sound/json/with/key/bSH9xED1ZjuA-M74D-cDdk")
#scritpt = """curl -X POST -H "Content-Type: application/json" -d '{"value1":"%s說：%s","value2":"","value3":""}' https://maker.ifttt.com/trigger/Alert/with/key/bSH9xED1ZjuA-M74D-cDdk > log.txt""" % (who,who_input)
#os.system(scritpt.encode('utf-8'))
url = "https://maker.ifttt.com/trigger/Alert/with/key/bSH9xED1ZjuA-M74D-cDdk"
headers = {
    "Content-Type": "application/json"
}
data = {
    "value1": "%s說:%s" % (who,who_input),
}
if who=="kiki":
    text_to_append = "%s,%s" % (now_time,who_input)
    with open("kiki.txt", "a", encoding="utf-8") as file:
        file.write(text_to_append + "\n")  # 添加换行符
    #os.system(scritpt.encode('utf-8'))
    #requests.post(url, headers=headers, json=data)
    requests.get("https://author.lugeshop.com/discord.php?message=%s&channel=note" % data["value1"])
    requests.get("https://author.lugeshop.com/linev2.php?message=%s" % data["value1"])
if who=="kiki_s":
    userpassword = 'ZmYxMTM1NjI='
    mailpassword = 'rkqlnddzjgcqnhln'
    a = makekey(random.randint(0,1))
    b = makekey(random.randint(0,1))
    c = makekey(random.randint(0,1))
    d = makekey(random.randint(0,1))
    e = makekey(random.randint(0,1))
    f = makekey(random.randint(0,1))
    n = '%s%s%s%s%s%s' % (a,b,c,d,e,f)
    curl_script="""curl --ssl-reqd \\
      --url 'smtps://smtp.gmail.com:465' \\
      --user 'yencloudleader@gmail.com:{0}' \\
      --mail-from 'yencloudleader@gmail.com' \\
      --mail-rcpt 'bi1012037@gmail.com' \\
      --upload-file {1}.txt""".format(mailpassword,n)
    subject = u"%s日記簿更新內容" % now_time
    email_content = '重整日記簿!【%s】' % who_input
    email_template="""From: "Lugeshop" <yencloudleader@gmail.com>
To: "bi1012037" <bi1012037@gmail.com>
Subject:{0}

{1}""".format(subject,email_content)
    with open("%s.txt" % n,'w',encoding="utf_8_sig") as f:
        f.write(email_template)
    os.system(curl_script)
    os.system("rm %s.txt" % n)
    # 輸入gmail信箱的資訊
    """userid = 'RjEyODc1MDIzMg=='
    username = 'YmkxMDEyMDM3'
    userpassword = ''
    host = "smtp.gmail.com"
    port = 587
    mailname = base64.b64decode("eWVuY2xvdWRsZWFkZXJAZ21haWwuY29t").decode("utf-8")
    mailpassword = base64.b64decode("").decode("utf-8")
    to_list = ["bi1012037@gmail.com"]
    from_email = mailname
    email_conn = smtplib.SMTP(host,port)
    # 試試看能否跟Gmail Server溝通
    #print(email_conn.ehlo())
    # TTLS安全認證機制
    email_conn.starttls()
    # 登錄mail
    ec = email_conn.login(mailname,mailpassword)
    #print(ec)
    #time.sleep(2)
    # 寄信
    the_msg = MIMEMultipart("alternative")
    # 開始郵件內容
    the_msg['Subject'] = u"%s日記簿更新內容" % now_time
    the_msg["From"] = mailname
    # 純文字部分
    html_txt = '重整日記簿!【%s】' % who_input
    # 紀錄純文字加上HTML格式
    part_1 = MIMEText(html_txt, 'html', 'utf-8')
    the_msg.attach(part_1)
    #print(the_msg.as_string()
    email_conn.sendmail(from_email, to_list, the_msg.as_string())

    # 關閉連線
    email_conn.quit()

    #print('Email sent!')"""
