import asyncio
import websockets
import subprocess
"""async def notify_clients(websocket, path):
    # 在需要的情況下向連接的客戶端發送訊息
    await websocket.send("RefreshPage")

start_server = websockets.serve(notify_clients, "localhost", 8765)

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()"""

result = subprocess.run(
    ['ssh', 'linchingyen@125.228.205.164', 'python E:\\sch\\run.py'],
    timeout=4,
)
