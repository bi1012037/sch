<?php

$content = file_get_contents('lst.txt');
$data = json_decode($content, true);
echo $data;


?>
