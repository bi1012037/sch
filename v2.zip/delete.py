# -*- coding: UTF-8 -*-
import time
import datetime
import os
import re
import base64
import requests
import sys
import codecs
import random
import smtplib
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

if os.path.dirname(__file__) != '':
    os.chdir(os.path.dirname(__file__))

key = sys.argv[1].encode('utf-8', errors='surrogateescape').decode('utf-8')
key = key.split('_')
who = key[0]
who_id = key[1]
try:
    version = key[2]
except:
    version = ""
try:
    with open("%s.txt" % who,"r",encoding="utf_8_sig") as v:
        vc = eval(v.read())
except:
    os.system('echo {} > %s.txt' % who)
    vc = {}

try:
    if "圖片上傳" in vc[int(who_id)]['who_input'] and "src" in vc[int(who_id)]['who_input']:
        file_path = vc[int(who_id)]['who_input'].split("src=")[-1].split('>')[0]
        os.system("rm %s" % file_path)
except:
    pass

del vc[int(who_id)]
with open("%s.txt" % who,"w",encoding="utf_8_sig") as v:
    v.write(str(vc))

if version != "2":
    js_script='''<script>parent.document.location.href="https://author.lugeshop.com/sch/search.php?who=%s"</script>''' % who
else:
    js_script= '''<script>parent.renew();</script>'''
print(js_script)

