echo '' > /var/www/html/sch/deer.txt
echo '' > /var/www/html/sch/kiki.txt
