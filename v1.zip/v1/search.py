# -*- coding: UTF-8 -*-
import time
import datetime
import os
import re
import base64
import requests
import sys
import codecs
import random
import smtplib
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

if os.path.dirname(__file__) != '':
    os.chdir(os.path.dirname(__file__))

now_time = datetime.datetime.now()
now_time = now_time.strftime("%Y-%m-%d %X")
fundnow = datetime.datetime.now()
fyear = fundnow.year
fmonth = fundnow.month
fday = fundnow.day
who = sys.argv[1].encode('utf-8', errors='surrogateescape').decode('utf-8')

status_dict={"0":"起床囉!",
             "1":"準備午餐中!",
             "2":"出門去!",
             "3":"工作中!",
             "4":"吃晚餐!",
             "5":"洗澡中!",
             "6":"愛睏中!",
             "7":"其他!"}


css='''<style>
.font_color{
    color:white;
}
#deer_sch_width,#kiki_sch_width{
    width:100%;
}
@media screen and (min-width: 768px){
    #deer_sch_width,#kiki_sch_width{
        width:45.5%;
    }
}
.deer_switch_change{
    background-color: #ff6781; //#fbfbfb;
    //border-bottom:1px #d3ced2 solid;
    //border-left:1px #d3ced2 solid;
    line-height:40px;
    border-top-right-radius:5px;
    //color:black;

}
.kiki_switch_change{
    background-color: #008CBA;
    //border-right:1px #d3ced2 solid;
    //border-bottom:1px #d3ced2 solid;
    line-height:40px;
    border-top-left-radius:5px;
    //color:black;
}

.form_line{
    border-left:1px #d3ced2 solid;
    border-right:1px #d3ced2 solid;
    border-bottom:1px #d3ced2 solid;
    border-top:1px #d3ced2 solid;
    border-collapse:separate;
    border-radius:5px;
}
.btn3 {
      font-family:DFKai-sb,Times New Roman;
      color: #0099CC;
      background: transparent;
      background-color: white;
      border: 2px solid red;
      border-radius: 10px;
      //border: none;
      color: black;
      text-align: center;
      display: inline-block;
      font-size: 16px;
      -webkit-transition-duration: 0.4s; /* Safari */
      transition-duration: 0.4s;
      cursor: pointer;
      text-decoration: none;
      text-transform: uppercase;
}
.btn3:hover {
      background-color:  red;
      color: white;
}
</style>'''
js_script='''<script>
function switch_close(elementor){
    elementor.forEach(function(value){
        document.getElementById(value).style.display="none";
    });
}
function switch_open(elementor){
    elementor.forEach(function(value){
        document.getElementById(value).style.display="";
    });
}
function delete_now(ele,ele_id){
    var r=confirm("是否刪除");
    if (r==true){
        document.querySelector("#myframe").src="https://author.lugeshop.com/sch/delete.php?who="+ele+"&status_id="+ele_id;
    }
}
</script>'''
print(css)
print(js_script)
print('<meta name="viewport" content="width=device-width, initial-scale=1">')
if who =="deer":
    deer_show = ''
    kiki_show='style="display:none"'
else:
    deer_show = 'style="display:none"'
    kiki_show =''
for name in ['deer','kiki']:
    try:
        with open("%s.txt" % name,"r",encoding="utf_8_sig") as v:
            vc = eval(v.read())
    except:
        os.system('echo {} > %s.txt' % name)
        vc = {}
    if name == 'deer':
        print('<div id="%s_form" align="center" %s><table id="deer_sch_width" class="form_line font_color" cellspacing=0 cellpadding=0>' % (name,deer_show))
        print('<tr><td colspan="4" style="padding:0px;"><div style="float:left;width:54%;height:40px;" align="center">小鹿</div><div style="float:right;width:46%;height:40px;" class="deer_switch_change" onclick="switch_close([\'deer_form\']);switch_open([\'kiki_form\']);" align="center">小琦</div></td></tr>')
    else:
        print('<div id="%s_form" align="center" %s><table id="kiki_sch_width" class="form_line font_color" cellspacing=0 cellpadding=0><tr>' % (name,kiki_show))
        print('<tr><td colspan="4" style="padding:0px;"><div style="float:left;width:46%;height:40px;" align="center" class="kiki_switch_change" onclick="switch_close([\'kiki_form\']);switch_open([\'deer_form\']);">小鹿</div><div style="float:right;width:54%;height:40px;" align="center">小琦</div></td></tr>')
    print('<tr><td width="15%" align="center">編號</td><td width="40%">狀態</td><td>操作時間</td><td align="center" width="10%">刪除</td></tr>')
    test = sorted(vc.keys(),reverse = True)
    index = 0
    for item in test:
        #index += 1
        print('<tr>')
        print("<td align='center'>%s</td>" % item)
        if vc[item]['who_input']=="":
            print("<td>%s</td>" % status_dict[vc[item]['who_status']])
        else:
            print("<td>%s-%s</td>" % (status_dict[vc[item]['who_status']],vc[item]['who_input']))
        print("<td>%s</td>" % vc[item]['who_time'])
        print("<td align='center'style='padding:5px'><button class='btn3' onclick='delete_now(\"%s\",\"%s\")'>刪除</button></td>" % (name,item))
        print('</tr>')
    if len(vc)==0:
        print('<tr><td colspan="3" align="center" style="color:red">查無資料</td></tr>')
    print('</table></div>')

print('<iframe id="myframe" name="myframe" height="100%" width="100%" frameborder="0" style="display:none;" scrolling="no"></iframe>')
js_script='''<script>
url = location.href;
argv = url.split("?who=");
try{
     if(argv[1]=="kiki"){
        switch_close(['deer_form']);
        switch_open(['kiki_form']);
    }else{
        switch_close(['kiki_form']);
        switch_open(['deer_form']);
    }
}catch{
    //console.log("無參數");
}
</script>'''
print(js_script)
