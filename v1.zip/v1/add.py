# -*- coding: UTF-8 -*-
import time
import datetime
import os
import re
import base64
import requests
import sys
import codecs
import random
import smtplib
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

if os.path.dirname(__file__) != '':
    os.chdir(os.path.dirname(__file__))

now_time = datetime.datetime.now()
now_time = now_time.strftime("%Y-%m-%d %X")
fundnow = datetime.datetime.now()
fyear = fundnow.year
fmonth = fundnow.month
fday = fundnow.day
key = sys.argv[1].encode('utf-8', errors='surrogateescape').decode('utf-8')
key = key.split('_')
who = key[0]
who_status = key[1]
who_input = key[2]
who_ip = key[3]

try:
    with open("%s.txt" % who,"r",encoding="utf_8_sig") as v:
        vc = eval(v.read())
        for i in vc:
            index = i
        index = int(index)+1
except:
    os.system('echo {} > %s.txt' % who)
    vc = {}
    index = 1

vc.setdefault( index ,"dafault")
vc[index]={"who_status":"%s" % who_status,"who_input":"%s" % who_input,"who_ip":"%s" % who_ip,"who_time":"%s" % now_time}
with open("%s.txt" % who,"w",encoding="utf_8_sig") as v:
    v.write(str(vc))
clean_script='''<script>parent.document.querySelector('#%s_send_input').value=''</script>''' % who
js_script='''<script>parent.document.querySelector("#myframe2").src="https://author.lugeshop.com/sch/search.php?who=%s"</script>''' % who
print(clean_script)
print(js_script)

